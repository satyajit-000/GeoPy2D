if __name__ == '__main__':
    from point import Point
    from line import Line
else:
    from GeoPy2D.point import Point
    from GeoPy2D.line import Line
import matplotlib.pyplot as plt
import numpy as np


class Circle:
    def __init__(self, **kwargs):
        self._g, self._f, self._c = [0]*3
        if 'centre' in kwargs and 'r' in kwargs:
            centre = kwargs['centre']
            self._g = -centre.x
            self._f = -centre.y
            self._c = round(centre.x**2 + centre.y**2 - kwargs['r']**2, 2)
            return
        if 'diameter' in kwargs:
            point1, point2 = kwargs['diameter']
            centre = Point.mid_point(point1, point2)
            radius = abs(point1 - point2)/2
            self._g = -centre.x
            self._f = -centre.y
            self._c = round(centre.x**2 + centre.y**2 - radius**2, 2)
            return
        if 'r' in kwargs:
            self._c = -kwargs['r']**2
        if 'g' in kwargs:
            self._g = kwargs['g']
        if 'f' in kwargs:
            self._f = kwargs['f']
        if 'c' in kwargs:
            self._c = kwargs['c']

    def __repr__(self):
        equation = "x² + y²"
        if self._g != 0:
            equation += f" + {2 * self._g}x"
        if self._f != 0:
            equation += f" + {2 * self._f}y"
        if self._c != 0:
            if self.centre == Point(0,0):
                return equation + f' = {-self._c}'
            else:
                if self._c > 0:
                    equation += f" + {self._c}"
                else:
                    equation += f" - {-self._c}"

        # else:
        #     equation = equation[:-3]

        return equation + ' = 0'
    
    def __eq__(self,other):
        return self.radius == other.radius and self.centre == other.center
    
    def __add__(self,other):
        g = (self._g + other._g)/2
        f = (self._f + other._f)/2
        c = (self._c + other._c)/2
        return Circle(g = g, f = f, c = c)
    
    def __sub__(self,other):
        a = 2*(self._g - other._g)
        b = 2*(self._f - other._f)
        c = self._c - other._c
        return Line(a = a, b = b, c = c).reduce 
    
    @property
    def centre_radius_repr(self):
        h,k = map(lambda a: round(a,2) ,(self.centre.x,self.centre.y))
        r = round(self.radius, 3)
        term1 = f"(x"
        if h >= 0:
            term1 += f" - {h}"
        elif h < 0:
            term1 += f" + {-h}"
        term2 = f" + (y"
        if k >= 0:
            term2 += f" - {k}"
        elif k < 0:
            term2 += f" + {-k}"
        return term1 + ")²" + term2 + f")² = ({r})²"
    @property
    def centre(self):
        return Point(-self._g, - self._f)

    @property
    def radius(self):
        return round(np.sqrt(self._g**2 + self._f**2 - self._c),2)

    @property
    def parametric_form(self):
        radius = self.radius
        centre = self.centre
        x = f'x ='
        if centre.x:
            x += f" {centre.x} +"
        y = f'y ='
        if centre.y:
            y += f" {centre.y} +"
        return (x + f" {radius} cos θ",y + f" {radius} sin θ")

    @property
    def intercepts_len(self):
        x_intercept = 2*round(np.sqrt(max(self._g**2 - self._c, 0)), 2)
        y_intercept = 2*round(np.sqrt(max(self._f**2 - self._c, 0)), 2)
        return (x_intercept, y_intercept)
    
    @property
    def  director_circle(self):
        print(self.centre)
        return Circle(r = ((self.radius * np.sqrt(2))), centre = self.centre)


    def pos_of_point(self, point):
        s = round(abs(point - self.centre) - self.radius,2)
        return round(s//abs(s)) if s else 0

    def pos_of_line(self, line):
        p = Line.perpendicular_distance(line, self.centre)
        return (p-self.radius)//abs(p-self.radius) if (p-self.radius) else 0

    def tangent(self, **kwargs):
        radius = self.radius
        centre = self.centre

        if 'point' in kwargs:
            point = kwargs['point']
            if self.pos_of_point(point) == 0:
                slope = -1/Point.slope(centre, point)
                tangent = Line(m=slope, point=point).reduce
                return (tangent,slope)
            else:
                print("Point is not on the circle")
                return None

        if 'm' in kwargs:
            m = kwargs['m']
            c = radius * round(np.sqrt(m**2 + 1),2)
            tangents = (Line(m=m, c=c).shift_origin(centre), Line(m=m, c=-c).shift_origin(centre))
            POC = tuple(
                map(lambda tangent: tangent.foot_of_perpendicular(centre), tangents))

            return (tangents, POC)

    @property
    def get_coef_(self):
        return (1, 1, self._g, self._f, self._c)
    
    def normal(self, **kwargs):
        radius = self.radius
        centre = self.centre

        if 'point' in kwargs:
            point = kwargs['point']
            normal =  Line(points=(centre,point))
            POC = point
            if radius != abs(point - centre):
                m1 = radius
                n1 = abs(point - centre) - radius
                POC1 = Point.internal_division(point1= centre, point2=point, m=m1, n=n1)
                POC2 = Point.inverse_mid_point(mid_point=centre,side_point=point)

            return (normal,(POC1,POC2))

        if 'm' in kwargs:
            m = kwargs['m']
            return Line(m = m, point = centre)

    def perpendicular_distance(self, point):
        return abs(abs(point - self.centre) - self.radius)
    
    def foot_of_perpendicular(self, point):
        m = self.perpendicular_distance(point)
        n = self.radius
        if self.pos_of_point(point) >= 0:
            return Point.internal_division(point1=point, point2= self.centre, m = m, n = n)
        else:
            return Point.external_division(point1=point, point2= self.centre, m = m, n = n)


    def image_of_a_point(self, point):
        foot = self.foot_of_perpendicular(point)
        return Point.inverse_mid_point(mid_point=foot, side_point=point)
    @classmethod
    def distance(cls,circle1,circle2):
        d = abs(circle1.centre - circle2.centre) - (circle1.radius + circle2.radius)
        return max(d,0)

    @classmethod
    def relative_pos(cls,*args):
        # if isinstance(all(x for x in args),Circle) and len(args) == 2:
        c1,c2 = map(lambda circle: circle.centre, args)
        c1c2 = abs(c1 - c2)
        r1,r2 = map(lambda circle: circle.radius, args)
        if args[0].pos_of_point(args[1].centre) == -1 or args[1].pos_of_point(args[0].centre) == -1:
            return (c1c2 - abs(r1 - r2))/abs(c1c2 - abs(r1 - r2)) if (c1c2 - abs(r1 - r2)) else 0
        else:
            return (c1c2 - (r1 + r2))/abs(c1c2 - (r1 + r2)) if (c1c2 - (r1 + r2)) else 0
        # else:
        #     print(type(args[0]), type(args[1]), len(args), "------------------------------------------------")
        #     raise AttributeError("Error in atrributes")

    @classmethod
    def common_tangents(cls,*args):
        if isinstance(all(x for x in args),Circle) and len(args) == 2:
            if Circle.relative_pos(*args) == 1:
                return 4
            elif Circle.relative_pos == 0:
                return 3
            else:
                return 2

    @classmethod
    def plot(cls, *args):
        # Create a figure and axis
        fig, ax = plt.subplots()
        plt.axis('equal')  # Set aspect ratio to ensure it's a circle

        for param in args:
            if isinstance(param, Circle):
                center = param.centre
                radius = param.radius

                theta = np.linspace(0, 2 * np.pi, 100)

                x = center.x + radius * np.cos(theta)
                y = center.y + radius * np.sin(theta)
                ax.set_xlim(center.x - radius - 5, center.x + radius + 5)
                ax.set_ylim(center.y - radius - 5, center.y + radius + 5)

                ax.plot(x, y, label=str(param.centre_radius_repr))
                ax.scatter(center.x, center.y)

            elif isinstance(param, Line):
                if param._b != 0:
                    x = np.linspace(-100, 100, 1000)
                    y = param.slope * x + param.y_intercept
                else:
                    y = np.linspace(-100, 100, 1000)
                    x = (y - param.y_intercept) / param.slope
                ax.plot(x, y, label=str(param))

            elif isinstance(param, Point):
                ax.scatter(param.x, param.y, label=str(param))

            else:
                raise ValueError(
                    "Invalid point or line provided. Must be an instance of Point or a line.")

        ax.set_xlabel('x-axis')
        ax.set_ylabel('y-axis')
        ax.set_title('Plotting Circles, Lines and Points')
        ax.legend(loc='upper right')
        ax.grid(True)
        # plt.show()
        plt.savefig('static/circle_plot.png')


# circle = Circle(r = 1, centre = Point(3,4))
# print(circle.center_radius_repr)
# print(circle.director_circle().center_radius_repr)

