import numpy as np
import matplotlib.pyplot as plt
import random
from fractions import Fraction
import math


if __name__ == '__main__' or __name__ == 'line':
    from point import Point
else:
    from GeoPy2D.point import Point


class Line:
    def __init__(self, **kwargs):
        self._a, self._b, self._c = 0, 0, 0 # Initialize all coefficient with zero
        fractions = {
            'a': 0, 
            'b': 0, 
            'c': 0
            } # To store fractional coefficient

        # Equation of line in 2 point Form
        if 'points' in kwargs:
            
            for point in kwargs['points']:
                if not isinstance(point, Point):
                    raise ValueError(
                        "Invalid point provided. Must be an instance of Point.")
                else:
                    point1, point2 = kwargs['points']
                    self._a = point2.y - point1.y
                    self._b = point1.x - point2.x
                    self._c = round((point2.x - point1.x) * point1.y,4) - round((point2.y - point1.y) * point1.x, 4)
                    a_fraction = Fraction(self._a).limit_denominator() # To make 'a' as Fraction
                    b_fraction = Fraction(self._b).limit_denominator() # To make 'b' as Fraction
                    c_fraction = Fraction(self._c).limit_denominator() # To make 'c' as Fraction
                    fractions['a'] = a_fraction # Storing the fractional value of a
                    fractions['b'] = b_fraction # Storing the fractional value of b
                    fractions['c'] = c_fraction # Storing the fractional value of c
        else:
            # Equation of line in point slope form
            if ('point' in kwargs and 'm' in kwargs) :

                if not isinstance(kwargs['point'], Point):
                    raise ValueError("Invalid point provided. Must be an instance of Point.")
                if not isinstance(kwargs['m'], (int,float)):
                    raise ValueError("Invalid slope provided. Must be an instance of int or float.")

                else:
                    self._a = kwargs['m']
                    if self._a != 0 or self._c != 0:
                        self._b = -1
                    self._c = kwargs['point'].y -  round(kwargs['m'] * kwargs['point'].x, 4)  
                    # print('-----------------------------------------',kwargs['m'], kwargs['point'].x ,round(kwargs['m'] * kwargs['point'].x, 4) )

                    # Extra part for further manipulation of coefficient       
                    m_fraction = Fraction(kwargs['m']).limit_denominator() # To make 'm' as Fraction
                    c_fraction = Fraction(self._c).limit_denominator() # To make 'c' as Fraction
                    fractions['a'] = m_fraction # Storing the fractional value of m
                    fractions['b'] = Fraction(self._b).limit_denominator()
                    fractions['c'] = c_fraction # Storing the fractional value of c

            # Equation of line in slope and y_intercept form
            else:
                if 'm'in kwargs :

                    if not isinstance(kwargs['m'], (int,float)):
                        raise ValueError("Invalid slope provided. Must be an instance of int or float.")

                    else:
                        self._a = kwargs['m']
                        # if self._a != 0 or self._c != 0:
                        self._b = -1
                        fractions['b'] = Fraction(-1,1)
                        fractions['c'] = Fraction(0,1)

                        # Extra part for further manipulation of coefficient 
                        m_fraction = Fraction(kwargs['m']).limit_denominator() # To make 'm' as Fraction
                        fractions['a'] = m_fraction # Storing the fractional value of m
                else:
                    # Equation of Line in General Form
                    if 'a' in kwargs :

                        if not isinstance(kwargs['a'], (int,float)):
                            raise ValueError("Invalid slope provided. Must be an instance of int or float.")

                        else:
                            self._a = kwargs['a']

                            # Extra part for further manipulation of coefficient 
                            a_fraction = Fraction(kwargs['a']).limit_denominator() # To make 'a' as Fraction
                            fractions['a'] = a_fraction  # Storing the fractional value of a

                    if 'b' in kwargs :

                        if not isinstance(kwargs['b'], (int,float)):
                            raise ValueError("Invalid slope provided. Must be an instance of int or float.")

                        else:
                            self._b = kwargs['b']

                            # Extra part for further manipulation of coefficient 
                            b_fraction = Fraction(kwargs['b']).limit_denominator() # To make 'b' as Fraction
                            fractions['b'] = b_fraction  # Storing the fractional value of b

                if 'c' in kwargs and (self._a !=0 or self._b != 0):
                    if not isinstance(kwargs['c'], (int,float)):
                        raise ValueError("Invalid slope provided. Must be an instance of int or float.")

                    else:
                        self._c = kwargs['c']

                        # Extra part for further manipulation of coefficient 
                        c_fraction = Fraction(kwargs['c']).limit_denominator() # To make 'c' as Fraction
                        fractions['c'] = c_fraction # Storing the fractional value of c
                # else:
                #     raise AttributeError("Invalid combination of coefficients. Either 'a' or 'b' must be provided when specifying 'c'.")

        # To Make the coefficient as integer
        lcm = math.lcm(fractions['a'].denominator,fractions['b'].denominator, fractions['c'].denominator)
        self._a = int(self._a * lcm)
        self._b = int(self._b * lcm)
        self._c = int(self._c * lcm)



        if self._a < 0:
            self._a *= -1
            self._b *= -1
            self._c *= -1

        return

    def __repr__(self, representation='standard'):
        equation = ""
        if self._a:
            equation += f"{self._a}x"
        if self._b:
            if equation:
                if self._b > 0:
                    equation += f" + {self._b}y"
                else:
                    equation += f" - {-self._b}y"
            else:
                equation += f"{self._b}y"

        if self._c:
            if self._c > 0:
                equation += f" + {self._c}"
            else:
                equation += f" - {-self._c}"
        # else:
        #     equation = equation[:-3]
        return equation + ' = 0'


    @property
    def slope_intercept_repr(self):
        m = self.slope
        c = self.y_intercept
        return f"y = {m}x + {c}"

    @property
    def slope(self):
        if self._a == self._b == 0:
            return "Undefined"
        elif self._b == 0:
            return float('inf')
        else:
            return -self._a/self._b

    @property
    def y_intercept(self):
        if self._a == self._b == 0:
            return "Undefined"
        elif self._b == 0:
            return float('inf')
        else:
            return -(self._c) / (self._b)

    @property
    def intercepts(self):
        x_inter = 0
        y_inter = 0
        if self._a == self._b == 0:
            return "Undefined"
        if self._a == 0:
            x_inter = float('inf')
        else:
            x_inter = -self._c/self._a
        if self._b == 0:
            y_inter = float('inf')
        else:
            y_inter = -self._c/self._b
        return x_inter, y_inter

    def __add__(self, other):
        return Line(a=self._a + other._a, b=self._b + other._b, c=self._c + other._c)

    # def __eq__(self, other):
    #     return self._a/other._a == self._b/other._b == self._c/other._c

    def __iadd__(self, other):
        if not isinstance(other, Line):
            raise ValueError(f"Cannot add Line and {type(other)}")

        self._a += other._a
        self._b += other._b
        self._c += other._c

        return self
    @property
    def get_coef_(self):
        return(self._a,self._b,self._c)
    
    def __sub__(self, other):
        return Line(a=self._a - other._a, b=self._b - other._b, c=self._c - other._c)

    def __mul__(self, n):
        return Line(a=self._a * n, b=self._b * n, c=self._c * n)

    def __imul__(self, n):
        if not isinstance(n, (int, float)):
            raise ValueError(
                f"Multiplication factor must be a numeric type, not {type(n)}")

        self._a *= n
        self._b *= n
        self._c *= n
        return self

    @property
    def reduce(self):
        hcf = math.gcd(self._a,self._b,self._c)
        self._a //= hcf
        self._b //= hcf
        self._c //= hcf
        return hcf
    @classmethod
    def solve(cls, line1, line2):
        delta = line1._a * line2._b - line2._a * line1._b
        delta_x = line1._b * line2._c - line2._b * line1._c
        delta_y = line1._c * line2._a - line2._c * line1._a

        if delta == delta_x == delta_y == 0:
            print(f"\n{line1} and \n{line2} are \nIdentical Lines")
            return None
        elif delta == 0:
            print(f"\n{line1} and \n{line2} are \nParallel Lines")
            return None
        else:
            p = Point(delta_x/delta, delta_y/delta)
            return p

    @classmethod
    def position(cls, *args):
        if len(args) != 2:
            raise ValueError("Both line and point must be provided.")
            return
        if isinstance(args[0], Line) and isinstance(args[1], Point):
            line = args[0]
            point = args[1]
        elif isinstance(args[1], Line) and isinstance(args[0], Point):
            line = args[1]
            point = args[0]
        else:
            raise ValueError("One line and one point must be provided.")
            return

        s = line._a * point.x + line._b * point.y + line._c
        m = line.slope
        if s == 0:
            print(f"Point{point} is on the line {line}")
            return 0
        elif  s*m > 0 :
            print(f"Point{point} is Bellow the line {line}")
            return 1
        else:
            print(f"Point{point} is Above the line {line}")
            return -1

    def position_of_2points(self, point1, point2):
        s1 = Line.position(self, point1)
        s2 = Line.position(self, point2)
        if s1 * s2 < 0:
            # print(f"Point{point1}, Point{point2} are in oposite sides of Line:{self}")
            return 'Oposite side'
        elif s1 * s2 > 0:
            # print(f"Point{point1}, Point{point2} are in same sides of Line:{self}")
            return 'Same side'
        else:
            # print(f"One of the point among {point1} and {point2} is on the Line:{self}")
            return "One of the point lie on the line"
    @classmethod
    def perpendicular_distance(cls, *args):
        if len(args) != 2:
            raise ValueError("Both line and point must be provided.")
            return
        if isinstance(args[0], Line) and isinstance(args[1], Point):
            line, point = args
            # point = args[1]
        elif isinstance(args[1], Line) and isinstance(args[0], Point):
            # line = args[1]
            point, line = args
        else:
            raise ValueError("Both line and point must be provided.")
            return
        line_point = line._a * point.x + line._b * point.y + line._c
        return abs(line_point / np.sqrt(line._a**2 + line._b**2))

    def image_of_a_point(self, point):
        foot = self.foot_of_perpendicular(point)
        return Point.inverse_mid_point(mid_point=foot, side_point=point)

    @property
    def random_point(self):
        x = random.randint(-10, 10)
        y = -(self._c + self._a * x)/self._b
        return Point(x, y)

    @classmethod
    def line_space(cls, self, other):
        if Line.solve(self, other) != None:
            return 0
        else:
            p1 = self.random_point
            p2 = other.foot_of_perpendicular(p1)
            return abs(p2 - p1)

    @classmethod
    def triangle_area_line(cls, line1, line2, line3):
        p12 = Line.solve(line1, line2)
        p23 = Line.solve(line2, line3)
        p31 = Line.solve(line3, line1)
        return Point.triangle_area(p12, p23, p31)

    @classmethod
    def isConcurrent(cls, line1, line2, line3):
        matrix = np.array([
            [line1._a, line1._b, line1._c],
            [line2._a, line2._b, line3._c],
            [line3._a, line2._b, line3._c]
        ])
        return np.linalg.det(matrix) == 0

    def get_coordinate(self, **kwargs):

        x = kwargs.get('x')
        y = kwargs.get('y')

        if x is not None and y is not None:
            raise ValueError("Provide either x or y, not both.")

        if x is not None:
            if self._b == 0:
                raise ValueError("Cannot calculate y-value for a vertical line.")
            else:
                return (-self._a * x - self._c) / self._b

        elif y is not None:
            if self._a == 0:
                raise ValueError("Cannot calculate x-value for a horizontal line.")
            else:
                return (-self._b * y - self._c) / self._a

        else:
            raise ValueError("Provide either x or y.")

    def foot_of_perpendicular(self, point):
        m_ = -1/self.slope
        new_l = Line(point=point, m=m_)
        return Line.solve(self, new_l)
    
    def min_point(self, limit = (-10,10)):
        if self.slope > 0:
            x =min(limit)
            y = self.get_coordinate(x = x)
        elif self.slope < 0:
            x = max(limit)
            y = self.get_coordinate(x = x)
        return Point(x,y)
    
    def max_point(self, limit=(-10,10)):
        if self.slope > 0:
            x = max(limit)
            y = self.get_coordinate(x = x)
        elif self.slope < 0:
            x =min(limit)
            y = self.get_coordinate(x = x)
        return Point(x,y)
    def copy(self):
        return Line(a = self._a, b = self._b, c = self._c)

    def rotate_axis(self,**kwargs):
        if 'rad' in kwargs:
            theta = kwargs['rad']
            A = round(self._a * np.cos(theta), 2) + round(self._b * np.sin(theta), 2)
            B = round(self._b * np.cos(theta), 2) - round(self._a * np.sin(theta), 2)
            C = self._c
            return Line(a = A, b = B, c = C)
        elif  'deg' in kwargs:
            theta = np.radians(kwargs['deg'])
            return self.rotate_axis(rad = theta)
    def shift_origin(self,point):
        # self._c += -self._a * point.x - self._b * point.y
        return Line(a = self._a, b = self._b, c = self._c + -self._a * point.x - self._b * point.y)
    @classmethod
    # Inside your Line class
    def plot(cls, *args):

        plt.figure()
        plt.axis('equal')  # Set aspect ratio to ensure it's a circle
        for param in args:
            if isinstance(param, Line):
                if param._b != 0:
                    x = np.linspace(-10, 10, 100)
                    y = param.slope * x + param.y_intercept
                else:
                    y = np.linspace(-10, 10, 100)
                    x = y - param.y_intercept / param.slope
                plt.plot(x, y, label=str(param))
                print(param)

            elif isinstance(param, Point):
                plt.scatter(param.x, param.y, label=str(param))
                print(param)


            else:
                raise ValueError(
                    "Invalid point or line provided. Must be an instance of Point or a line.")

        plt.xlabel('x-axis')
        plt.ylabel('y-axis')
        plt.title('Plotting Lines and Points')
        plt.legend()
        plt.grid(True)
       
        # Set the x and y axis limits to control the unit length
        plt.xlim(-10, 10)  # Set your desired x-axis limits
        plt.ylim(-10, 10)  # Set your desired y-axis limits
        # plt.show()
        plt.savefig('static/line_plot.png')


# print(Line(m = 0, c = 7))