import numpy as np
import matplotlib.pyplot as plt

class Point:
    def __init__(self, x, y):
        self.x = round(x, 2)
        self.y = round(y, 2)

    def __repr__(self):
        return f"({self.x}, {self.y})"

    def __abs__(self):
        return np.sqrt(self.x**2 + self.y**2)

    def __sub__(self, other):
        return Point(other.x - self.x, other.y - self.y)

    def __eq__(self, other):
        return self.x == other.x and self.y == other.y

    def copy(self):
        return Point(self.x, self.y)

    @classmethod
    def toPolar(cls, self, deg=False):
        r = abs(self)
        if self.y == 0:
            theta = 0
        elif self.x == 0:
            theta = np.pi/2
        else:
            theta = np.arctan(self.y/self.x)
        if deg:
            return (round(r,2), round(theta*(180/np.pi),2))
        else:
            return (round(r), round(theta,2))
    
    @classmethod
    def slope(cls,point1,point2):
        return(point2.y - point1.y) / (point2.x - point1.x) if (point2.x - point1.x) else float('inf')
    

    def rotate(self, **kwargs):
        r, theta = Point.toPolar(self)
        if 'rad' in kwargs:
            alpha = kwargs['rad']
            self.x = round(r * np.cos(theta + alpha), 2)
            self.y = round(r * np.sin(theta + alpha), 2)
        elif 'deg' in kwargs:
            rad = np.radians(kwargs['deg'])
            self.rotate(rad=rad)
        else:
            raise AttributeError("Invalid rotation arguments.")
        return self

    @property
    def position(self):
        if self.x > 0 and self.y > 0:
            print("First Quadrant")
            return "First Quadrant"
        elif self.x < 0 and self.y > 0:
            print("Second Quadrant")
            return "Second Quadrant"
        elif self.x < 0 and self.y < 0:
            print("Second Quadrant")
            return "Second Quadrant"
        elif self.x > 0 and self.y < 0:
            print("Fourth Quadrant")
            return "Fourth Quadrant"
        elif self.x == 0 and self.y != 0:
            print("On x-axis")
            return "On x-axis"
        elif self.x != 0 and self.y == 0:
            print("On y_axis")
            return "On y_axis"
        elif self.x == 0 and self.y == 0:
            print("Origin")
            return "Origin"

    @classmethod
    def triangle_area(cls, self, other, another):
        matrix = np.array([
            [self.x, self.y, 1],
            [other.x, other.y, 1],
            [another.x, another.y, 1]
        ])
        return abs(np.linalg.det(matrix))

    @classmethod
    def isColinear(cls, self, other, another):
        return cls.triangle_area(self, other, another) == 0

    @classmethod
    def equidistance(cls, *args):
        d = abs(args[0] - args[1])
        for i in range(2, len(args) - 1):
            if d != abs(args[0] - args[i]):
                return False
        return True

    @classmethod
    def mid_point(cls, point1, point2):
        x = (point1.x + point2.x)/2
        y = (point1.y + point2.y)/2
        return Point(x, y)
    
    @classmethod
    def inverse_mid_point(cls, mid_point, side_point):
        x = 2*mid_point.x - side_point.x
        y = 2*mid_point.y - side_point.y
        return Point(x,y)

    @classmethod
    def centroid(cls, point1, point2, point3):
        x = (point1.x + point2.x + point3.x) / 3
        y = (point1.y + point2.y + point3.y) / 3
        return Point(x, y)

    @classmethod
    def internal_division(cls, point1, point2, m, n):
        x = (m * point2.x + n * point1.x)/(m + n)
        y = (m * point2.y + n * point1.y)/(m + n)
        return Point(x, y)

    @classmethod
    def external_division(cls, point1, point2, m, n):
        x = (m * point2.x - n * point1.x)/(m - n)
        y = (m * point2.y - n * point1.y)/(m - n)
        return Point(x, y)
    
    def shift_origin(self,point):
        self.x = self.x - point.x
        self.y = self.y - point.y
        return self

    def rotate_axis(self, **kwargs):
        if 'rad' in kwargs:
            theta = kwargs['rad']
            self.x = round(self.x * np.cos(theta) + self.y * np.sin(theta),2)
            self.y = round(self.y * np.cos(theta) - self.x * np.sin(theta),2)
        elif 'deg' in kwargs:
            rad = kwargs['deg'] * (np.pi / 180)
            self.rotate_axis(rad = rad)
        else:
            raise AttributeError("Invalid rotation argument. Use 'rad' for radians or 'deg' for degrees.")
        return self

    @classmethod
    def plot_points(cls, *args):
        if not args:
            raise ValueError("At least one Point instance must be provided.")
        
        # Create a new figure for each plot
        plt.figure()
        plt.axis('equal')  # Set aspect ratio to ensure it's a circle

        for point in args:
            if not isinstance(point, Point):
                raise ValueError(
                    f"Invalid point provided for {point}. Must be an instance of Point.")
            plt.scatter(point.x, point.y, label=str(point))

        plt.xlabel('x-axis')
        plt.ylabel('y-axis')
        plt.title('Plotting Points')
        plt.legend()
        plt.grid(True)
        # plt.show()
        # if len(args) == 1:
        #     plt.savefig('static/point_plot.png')
        # else:
        plt.savefig('static/points_plot.png')


