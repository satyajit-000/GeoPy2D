# import numpy as np
# import matplotlib.pyplot as plt
# import random
from fractions import Fraction
import math

try:
    from point import Point
    from line import Line
except:
    from GeoPy2D.point import Point
    from GeoPy2D.line import Line


class Pair_of_lines:
    def __init__(self, **kwargs):
        # Initialize all coefficient with zero
        self._a, self._b,self._h, self._g, self._f, self._c, = 6*[0]

        # Equation of line in 2 point Form
        if 'lines' in kwargs:
            for line in kwargs['lines']:
                if not isinstance(line, Line):
                    raise ValueError(
                        "Invalid point provided. Must be an instance of Point.")
                else:
                    line1, line2 = kwargs['lines']
                    self._a = line1._a * line2._a
                    self._b = line1._b * line2._b
                    self._h = (line1._a * line2._b + line2._a * line1._b) / 2
                    self._g = (line1._a * line2._c + line2._a * line1._c) / 2
                    self._f = (line1._b * line2._c + line2._b * line1._c) / 2
                    self._c = line1._c * line2._c
                    return
        else:
            fractions = {
            'a': 0,
            'b': 0,
            'h': 0,
            'g': 0,
            'f': 0,
            'c': 0
        }  # To store fractional coefficient
            if 'a' in kwargs:

                if not isinstance(kwargs['a'], (int, float)):
                    raise ValueError(
                        "Invalid coefficient provided. Must be an instance of int or float.")

                else:
                    self._a = kwargs['a']

                    # Extra part for further manipulation of coefficient
                    # To make 'a' as Fraction
                    a_fraction = Fraction(
                        kwargs['a']).limit_denominator()
                    # Storing the fractional value of a
                    fractions['a'] = a_fraction

            if 'b' in kwargs:

                if not isinstance(kwargs['b'], (int, float)):
                    raise ValueError(
                        "Invalid coefficient provided. Must be an instance of int or float.")

                else:
                    self._b = kwargs['b']

                    # Extra part for further manipulation of coefficient
                    # To make 'b' as Fraction
                    b_fraction = Fraction(
                        kwargs['b']).limit_denominator()
                    # Storing the fractional value of b
                    fractions['b'] = b_fraction
            
            if 'h' in kwargs:

                if not isinstance(kwargs['h'], (int, float)):
                    raise ValueError(
                        "Invalid coefficient provided. Must be an instance of int or float.")

                else:
                    self._h = kwargs['h']

                    # Extra part for further manipulation of coefficient
                    # To make 'b' as Fraction
                    h_fraction = Fraction(kwargs['h']).limit_denominator()
                    # Storing the fractional value of b
                    fractions['h'] = h_fraction
            if 'g' in kwargs:

                if not isinstance(kwargs['g'], (int, float)):
                    raise ValueError(
                        "Invalid coefficient provided. Must be an instance of int or float.")

                else:
                    self._g = kwargs['g']

                    # Extra part for further manipulation of coefficient
                    # To make 'b' as Fraction
                    g_fraction = Fraction(
                        kwargs['g']).limit_denominator()
                    # Storing the fractional value of b
                    fractions['g'] = g_fraction
            if 'f' in kwargs:

                if not isinstance(kwargs['f'], (int, float)):
                    raise ValueError(
                        "Invalid coefficient provided. Must be an instance of int or float.")

                else:
                    self._f = kwargs['f']

                    # Extra part for further manipulation of coefficient
                    # To make 'b' as Fraction
                    f_fraction = Fraction(
                        kwargs['f']).limit_denominator()
                    # Storing the fractional value of b
                    fractions['f'] = f_fraction

            if 'c' in kwargs and (self._a != 0 or self._b != 0):
                if not isinstance(kwargs['c'], (int, float)):
                    raise ValueError(
                        "Invalid constant provided. Must be an instance of int or float.")

                else:
                    self._c = kwargs['c']

                    # Extra part for further manipulation of coefficient
                    # To make 'c' as Fraction
                    c_fraction = Fraction(kwargs['c']).limit_denominator()
                    # Storing the fractional value of c
                    fractions['c'] = c_fraction
            # else:
            #     raise AttributeError("Invalid combination of coefficients. Either 'a' or 'b' must be provided when specifying 'c'.")

            # To Make the coefficient as integer
            lcm = math.lcm(fractions['a'].denominator,
                        fractions['b'].denominator,
                        fractions['h'].denominator,
                        fractions['g'].denominator,
                        fractions['f'].denominator,
                        fractions['c'].denominator)
            self._a = int(self._a * lcm)
            self._b = int(self._b * lcm)
            self._h = int(self._h * lcm)
            self._g = int(self._g * lcm)
            self._f = int(self._f * lcm)
            self._c = int(self._c * lcm)

            if self._a < 0:
                self._a *= -1
                self._b *= -1
                self._h *= -1
                self._g *= -1
                self._f *= -1
                self._c *= -1

            return
    
    def __repr__(self):
        equation = ""
        if self._a != 0:
            equation += f"{self._a}x²"
        if self._b != 0:
            if equation:
                if self._b > 0:
                    equation += f" + {self._b}y²"
                else:
                    equation += f" - {-self._b}y²"
            else:
                equation += f"{self._b}y²"
        if self._h != 0:
            if equation:
                if self._h > 0:
                    equation += f" + {int(2 * self._h)}xy"
                else:
                    equation += f" - {-int(2 *self._h)}xy"
            else:
                equation += f"{2 *self._h}xy"

        if self._g != 0:
            if equation:
                if self._g > 0:
                    equation += f" + {int(2 * self._g)}x"
                else:
                    equation += f" - {-int(2 *self._g)}x"
            else:
                equation += f"{2 *self._g}x"
        if self._f != 0:
            if equation:
                if self._f > 0:
                    equation += f" + {int(2 * self._f)}y"
                else:
                    equation += f" - {-int(2 *self._f)}y"
            else:
                equation += f"{2 *self._f}y"
        
        if self._c:
            if self._c > 0:
                equation += f" + {self._c}"
            else:
                equation += f" - {-self._c}"
        
        return equation + " = 0"

    @property
    def get_coef_(self):
        return (self._a, self._b, self._h, self._g, self._f, self._c)
# print(Line(points = (Point(0,0), Point(1,1))))
# print(Line(m=-.5, c=1))
# print(Pair_of_lines(lines = (Line(points = (Point(0,0), Point(1,1))), Line(m = -.5, c = 1))))