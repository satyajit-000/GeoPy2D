from flask import Flask, render_template, request
from GeoPy2D.point import Point
from GeoPy2D.line import Line
from GeoPy2D.circle import Circle

app = Flask(__name__)

# Home Page


@app.route('/')
def index():
    return render_template('index.html')
# Point Sections


@app.route('/point',  methods=['POST', 'GET'])
def point():
    if request.method == 'POST':
        x_val = float(request.form['x_val'])
        y_val = float(request.form['y_val'])
        # global point
        point = Point(x_val, y_val)
        Point.plot_points(point)

        return render_template('point/point_operations.html', point=point, abs=abs(point), pos=point.position, polar=Point.toPolar(point, deg=True))

    return render_template('point/point.html')


@app.route('/point/rotate', methods=["GET", 'POST'])
def rotate_form():
    if request.method == "POST":
        x_val = float(request.form['x_val'])
        y_val = float(request.form['y_val'])
        point = Point(x_val, y_val)
        rotate_option = request.form.get('rotateOption')
        rotate_value = float(request.form.get('rotateValue'))
        old = point.copy()
        if rotate_option == 'deg':
            point.rotate(deg=rotate_value)
        else:
            point.rotate(rad=rotate_value)
        Point.plot_points(old, point, Point(0, 0))
        return render_template('point/rotate_point.html', oldpoint=old, rotate_option=rotate_option, rotate_value=rotate_value, newpoint=point)
    return render_template('point/rotate_point.html')


@app.route('/point/rotate_axis', methods=['GET', 'POST'])
def rotate_axis():
    if request.method == "POST":
        x_val = float(request.form['x_val'])
        y_val = float(request.form['y_val'])
        point = Point(x_val, y_val)
        rotate_option = request.form.get('rotateOption')
        rotate_value = float(request.form.get('rotateValue'))
        old = point.copy()
        if rotate_option == 'deg':
            point.rotate_axis(deg=rotate_value)
        else:
            point.rotate_axis(rad=rotate_value)
        Point.plot_points(old, point, Point(0, 0))
        return render_template('point/rotate_axis.html', oldpoint=old, rotate_option=rotate_option, rotate_value=rotate_value, newpoint=point)
    else:
        return render_template('point/rotate_axis.html')


pointlist = []


@app.route('/point/PlotPoints', methods=['POST', 'GET'])
def PlotPoints():
    if request.method == 'POST':
        x_values = [int(x) for x in request.form.getlist('x_val[]')]
        y_values = [int(y) for y in request.form.getlist('y_val[]')]

        # Process the points (you can do something with them)
        global points
        points = [Point(*coords) for coords in zip(x_values, y_values)]

        pointlist.extend(points)
        Point.plot_points(*points)
        return render_template('point/plot_points.html', points=pointlist)
    else:
        return render_template('point/plot_points.html')


@app.route('/point/midpoint', methods=['GET', "POST"])
def midpoint():
    if request.method == 'POST':
        x1 = float(request.form['x_val1'])
        y1 = float(request.form['y_val1'])
        x2 = float(request.form['x_val2'])
        y2 = float(request.form['y_val2'])
        p1 = Point(x1, y1)
        p2 = Point(x2, y2)
        midpoint = Point.mid_point(p1, p2)
        Point.plot_points(p1,p2,midpoint)
        return render_template("point/midpoint.html", midpoint=midpoint, points=(p1, p2))
    else:
        return render_template("point/midpoint.html", midpoint=None)


@app.route('/point/area_of_triangle', methods=['GET', 'POST'])
def area_of_triangle():
    if request.method == 'POST':
        x1 = float(request.form['x1'])
        y1 = float(request.form['y1'])
        x2 = float(request.form['x2'])
        y2 = float(request.form['y2'])
        x3 = float(request.form['x3'])
        y3 = float(request.form['y3'])
        p1 = Point(x1, y1)
        p2 = Point(x2, y2)
        p3 = Point(x3, y3)
        area = Point.triangle_area(p1, p2, p3)
        return render_template("point/area.html", area=area, points=(p1, p2, p3))
    else:
        return render_template("point/area.html", area=None)


@app.route('/point/internaldiv', methods=['GET', 'POST'])
def internaldiv():
    if request.method == 'POST':
        x1 = float(request.form['x1'])
        y1 = float(request.form['y1'])
        x2 = float(request.form['x2'])
        y2 = float(request.form['y2'])
        m = int(request.form['m'])
        n = int(request.form['n'])

        p1 = Point(x1, y1)
        p2 = Point(x2, y2)

        internaldiv = Point.internal_division(p1, p2, m, n)
        return render_template("point/internaldiv.html", internaldiv=internaldiv, points=(p1, p2), m=m, n=n)
    else:
        return render_template("point/internaldiv.html", internaldiv=None)


@app.route('/point/externaldiv', methods=['GET', 'POST'])
def externaldiv():
    if request.method == 'POST':
        x1 = float(request.form['x1'])
        y1 = float(request.form['y1'])
        x2 = float(request.form['x2'])
        y2 = float(request.form['y2'])
        m = int(request.form['m'])
        n = int(request.form['n'])

        p1 = Point(x1, y1)
        p2 = Point(x2, y2)

        externaldiv = Point.external_division(p1, p2, m, n)
        return render_template("point/externaldiv.html", externaldiv=externaldiv, points=(p1, p2), m=m, n=n)
    else:
        return render_template("point/externaldiv.html", externaldiv=None)


@app.route('/point/centroid', methods=['GET', 'POST'])
def centroid():
    if request.method == 'POST':
        x1 = float(request.form['x1'])
        y1 = float(request.form['y1'])
        x2 = float(request.form['x2'])
        y2 = float(request.form['y2'])
        x3 = float(request.form['x3'])
        y3 = float(request.form['y3'])
        p1 = Point(x1, y1)
        p2 = Point(x2, y2)
        p3 = Point(x3, y3)
        centroid = Point.centroid(p1, p2, p3)
        return render_template("point/centroid.html", centroid=centroid, points=(p1, p2, p3))
    else:
        return render_template("point/centroid.html", centroid=None)


# Line section
line_obj = None


@app.route('/line', methods=['GET', 'POST'])
def line():
    return render_template('line/line.html')


@app.route('/line/properties', methods=['POST'])
def line_properties():
    equation_type = request.form.get('equationType')
    global line_obj
    if equation_type == 'standard':
        A = float(request.form.get('aCoefficient'))
        B = float(request.form.get('bCoefficient'))
        C = float(request.form.get('cConstant'))
        line_obj = Line(a=A, b=B, c=C)
        line_obj.reduce
        Line.plot(line_obj)

    elif equation_type == 'slopeIntercept':
        m = float(request.form.get('slope'))
        C = float(request.form.get('yIntercept'))
        line_obj = Line(m=m, c=C)
        line_obj.reduce
        Line.plot(line_obj)

    elif equation_type == 'pointSlope':
        m = float(request.form.get('pointSlopeM'))
        x = float(request.form.get('pointSlopeX'))
        y = float(request.form.get('pointSlopeY'))
        p = Point(x, y)
        line_obj = Line(m=m, point=p)
        line_obj.reduce
        Line.plot(line_obj, p)

    elif equation_type == 'twoPoint':
        x1 = float(request.form.get('twoPointX1'))
        y1 = float(request.form.get('twoPointY1'))
        p1 = Point(x1, y1)
        x2 = float(request.form.get('twoPointX2'))
        y2 = float(request.form.get('twoPointY2'))
        p2 = Point(x2, y2)
        line_obj = Line(points=(p1, p2))
        line_obj.reduce
        Line.plot(line_obj, p1, p2)

    if line_obj:
        # line_obj.representation = 'slope_intercept'
        slope = line_obj.slope
        x_intercept, y_intercept = line_obj.intercepts

    return render_template('line/line_operations.html', lines=(line_obj, line_obj.slope_intercept_repr), slope=slope, y_intercept=y_intercept, x_intercept=x_intercept)


@app.route('/line/solve', methods=['POST', 'GET'])
def solve():
    if request.method == 'POST':
        A1 = float(request.form.get('aCoefficient1'))
        B1 = float(request.form.get('bCoefficient1'))
        C1 = float(request.form.get('cConstant1'))
        line1 = Line(a=A1, b=B1, c=C1)

        A2 = float(request.form.get('aCoefficient2'))
        B2 = float(request.form.get('bCoefficient2'))
        C2 = float(request.form.get('cConstant2'))
        line2 = Line(a=A2, b=B2, c=C2)
        solution_point = Line.solve(line1=line1, line2=line2)
        Line.plot(line1, line2, solution_point)
        return render_template("line/solve.html", line1=line1, line2=line2, solution_point=solution_point)

    return render_template("line/solve.html", solution_point=None)


@app.route('/line/areaOfTriangle', methods=['GET', 'POST'])
def areaOfTriangle():
    if request.method == 'POST':
        A1 = float(request.form.get('aCoefficient1'))
        B1 = float(request.form.get('bCoefficient1'))
        C1 = float(request.form.get('cConstant1'))
        line1 = Line(a=A1, b=B1, c=C1)

        A2 = float(request.form.get('aCoefficient2'))
        B2 = float(request.form.get('bCoefficient2'))
        C2 = float(request.form.get('cConstant2'))
        line2 = Line(a=A2, b=B2, c=C2)

        A3 = float(request.form.get('aCoefficient3'))
        B3 = float(request.form.get('bCoefficient3'))
        C3 = float(request.form.get('cConstant3'))
        line3 = Line(a=A3, b=B3, c=C3)

        area = Line.triangle_area_line(line1, line2, line3)
        return render_template("line/area_line.html", line1=line1, line2=line2, line3=line3, area=area)
    return render_template('line/area_line.html', area=None)


@app.route('/line/distance', methods=['GET', 'POST'])
def distance():
    if request.method == 'POST':
        A1 = float(request.form.get('aCoefficient1'))
        B1 = float(request.form.get('bCoefficient1'))
        C1 = float(request.form.get('cConstant1'))
        line1 = Line(a=A1, b=B1, c=C1)

        C2 = float(request.form.get('cConstant2'))
        line2 = Line(a=A1, b=B1, c=C2)
        distance = Line.line_space(line1, line2)
        Line.plot(line1, line2)
        return render_template("line/distance.html", line1=line1, line2=line2, distance=distance)
    return render_template('line/distance.html', distance=None)


@app.route('/line/testForConcurrent', methods=['GET', 'POST'])
def testForConcurrent():
    if request.method == 'POST':
        A1 = float(request.form.get('aCoefficient1'))
        B1 = float(request.form.get('bCoefficient1'))
        C1 = float(request.form.get('cConstant1'))
        line1 = Line(a=A1, b=B1, c=C1)

        A2 = float(request.form.get('aCoefficient2'))
        B2 = float(request.form.get('bCoefficient2'))
        C2 = float(request.form.get('cConstant2'))
        line2 = Line(a=A2, b=B2, c=C2)

        A3 = float(request.form.get('aCoefficient3'))
        B3 = float(request.form.get('bCoefficient3'))
        C3 = float(request.form.get('cConstant3'))
        line3 = Line(a=A3, b=B3, c=C3)
        if Line.isConcurrent(line1, line2, line3):
            result = 'Concurrent'
            POC = Line.solve(line1, line2)
            Line.plot(line1, line2, line3, POC)
            return render_template("testForConcurrent.html", line1=line1, line2=line2, line3=line3, result=result, POC=POC)
        else:
            result = 'not Concurrent'
            Line.plot(line1, line2, line3)
            return render_template("line/testForConcurrent.html", line1=line1, line2=line2, line3=line3, result=result)

    return render_template('line/testForConcurrent.html')


linelist = []


@app.route('/line/plot_graph', methods=['GET', 'POST'])
def plot():

    pointlist.clear()
    if request.method == 'POST':

        x_values = [float(x) for x in request.form.getlist('x_val[]')]
        y_values = [float(y) for y in request.form.getlist('y_val[]')]

        points = [Point(*coords) for coords in zip(x_values, y_values)]

        pointlist.extend(points)

        A_values = request.form.getlist('aCoefficient[]')
        B_values = request.form.getlist('bCoefficient[]')
        C_values = request.form.getlist('cConstant[]')

        lines = [Line(a=float(a), b=float(b), c=float(c))
                 for a, b, c in zip(A_values, B_values, C_values)]

        linelist.extend(lines)

        Line.plot(*(linelist + pointlist))
        return render_template('line/plot.html', points=pointlist, lines=linelist)
    return render_template('line/plot.html')


@app.route('/line/perpendicularDistance', methods=['GET', 'POST'])
def perpendicularDistance():
    if request.method == 'POST':
        x_val = float(request.form['x_val'])
        y_val = float(request.form['y_val'])
        point = Point(x_val, y_val)
        A = float(request.form.get('aCoefficient'))
        B = float(request.form.get('bCoefficient'))
        C = float(request.form.get('cConstant'))
        line_obj = Line(a=A, b=B, c=C)
        distance = Line.perpendicular_distance(point, line_obj)
        Line.plot(line_obj, point)
        return render_template('line/perpendicular_distance.html', point=point, line=line_obj, distance=distance)
    return render_template('line/perpendicular_distance.html', distance=None)


@app.route('/line/footOfPerpendicular', methods=['GET', 'POST'])
def foot_of_perpendicular():
    if request.method == 'POST':
        x_val = float(request.form['x_val'])
        y_val = float(request.form['y_val'])
        point = Point(x_val, y_val)
        A = float(request.form.get('aCoefficient'))
        B = float(request.form.get('bCoefficient'))
        C = float(request.form.get('cConstant'))
        line_obj = Line(a=A, b=B, c=C)
        foot = line_obj.foot_of_perpendicular(point)
        Line.plot(line_obj, point, foot)
        return render_template('line/foot_of_perpendicular.html', point=point, line=line_obj, foot=foot)
    return render_template('line/foot_of_perpendicular.html', foot=None)


@app.route('/line/positionOfPoint', methods=['GET', 'POST'])
def positionOfPoint():
    if request.method == 'POST':
        x_val = float(request.form['x_val'])
        y_val = float(request.form['y_val'])
        point = Point(x_val, y_val)
        A = float(request.form.get('aCoefficient'))
        B = float(request.form.get('bCoefficient'))
        C = float(request.form.get('cConstant'))
        line_obj = Line(a=A, b=B, c=C)
        result = Line.position(line_obj, point)
        if result == 0:
            pos = 'On'
        elif result == 1:
            pos = 'Bellow'
        else:
            pos = 'Above'

        Line.plot(line_obj, point)
        return render_template('line/point_position_to_line.html', point=point, line=line_obj, pos=pos)
    return render_template('line/point_position_to_line.html', pos=None)


@app.route('/line/positionOfTwoPoints', methods=['GET', 'POST'])
def positionOf2Points():
    if request.method == 'POST':
        x_val1 = float(request.form['x_val1'])
        y_val1 = float(request.form['y_val1'])
        point1 = Point(x_val1, y_val1)

        x_val2 = float(request.form['x_val2'])
        y_val2 = float(request.form['y_val2'])
        point2 = Point(x_val2, y_val2)

        A = float(request.form.get('aCoefficient'))
        B = float(request.form.get('bCoefficient'))
        C = float(request.form.get('cConstant'))
        line_obj = Line(a=A, b=B, c=C)

        pos = line_obj.position_of_2points(point1=point1, point2=point2)
        Line.plot(line_obj, point1, point2)
        return render_template('line/posOf2Points.html', points=(point1, point2), line=line_obj, pos=pos)

    return render_template('line/posOf2Points.html', pos=None)


# circle
@app.route('/circle')
def circle():
    return render_template('circle/circle.html')


@app.route('/circle/properties', methods=['GET', 'POST'])
def circle_properties():
    equation_type = request.form.get('equationType')
    global circle_obj
    if equation_type == 'standard':
        r = float(request.form.get('radius'))
        circle_obj = Circle(r=r)
        Circle.plot(circle_obj)

    elif equation_type == 'centreRadius':
        r = float(request.form.get('radius2'))
        h = float(request.form.get('hCentre'))
        k = float(request.form.get('kCentre'))
        centre = Point(h, k)
        circle_obj = Circle(centre=centre, r=r)
        Circle.plot(circle_obj)

    elif equation_type == 'general':
        g = float(request.form.get('gCoefficient'))
        f = float(request.form.get('fCoefficient'))
        c = float(request.form.get('cConstant'))
        circle_obj = Circle(g=g, f=f, c=c)
        Circle.plot(circle_obj)

    elif equation_type == 'twoPoint':
        x1 = float(request.form.get('twoPointX1'))
        y1 = float(request.form.get('twoPointY1'))
        p1 = Point(x1, y1)
        x2 = float(request.form.get('twoPointX2'))
        y2 = float(request.form.get('twoPointY2'))
        p2 = Point(x2, y2)
        circle_obj = Circle(diameter=(p1, p2))
        Circle.plot(circle_obj, p1, p2)

    return render_template('circle/circle_operations.html', circles=(circle_obj, circle_obj.centre_radius_repr, circle_obj.parametric_form), radius=circle_obj.radius, centre=circle_obj.centre, intercepts_len=circle_obj.intercepts_len)


@app.route("/circle/tangent", methods=['GET', 'POST'])
def tangent():
    if request.method == 'POST':
        g = float(request.form.get('gCoefficient'))
        f = float(request.form.get('fCoefficient'))
        c = float(request.form.get('cConstant'))
        circle = Circle(g=g, f=f, c=c)

        itemGiven = request.form['item']
        if itemGiven == 'slopeForm':
            m = float(request.form.get('slope'))
            tangents, POC = circle.tangent(m=m)
            Circle.plot(circle, *tangents, *POC)
            return render_template("circle/circle_tangent.html", m=m, circle=circle, tangents=tangents, tangent=None, POC=POC)

        elif itemGiven == 'pointForm':
            x_val = float(request.form.get('x_val', 0))
            y_val = float(request.form.get('y_val', 0))

            point = Point(x_val, y_val)
            print(point)
            tangent, slope = circle.tangent(point=point)
            Circle.plot(circle, tangent, point)
            return render_template("circle/circle_tangent.html", m=slope, circle=circle, tangents=None, tangent=tangent, point=point)
    else:
        return render_template("circle/circle_tangent.html", tangent=None, tangents=None)


@app.route("/circle/normal", methods=['GET', 'POST'])
def normal():
    if request.method == 'POST':
        g = float(request.form.get('gCoefficient'))
        f = float(request.form.get('fCoefficient'))
        c = float(request.form.get('cConstant'))
        circle = Circle(g=g, f=f, c=c)

        itemGiven = request.form['item']
        if itemGiven == 'slopeForm':
            m = float(request.form.get('slope'))
            normal = circle.normal(m=m)
            Circle.plot(circle, normal)
            return render_template("circle/circle_normal.html", m=m, circle=circle, normal=normal, slopeForm=True)

        elif itemGiven == 'pointForm':
            x_val = float(request.form['x_val'])
            y_val = float(request.form['y_val'])
            point = Point(x_val, y_val)
            normal, POC = circle.normal(point=point)
            Circle.plot(circle, normal, point, *POC)
            return render_template("circle/circle_normal.html", m=normal.slope, circle=circle, normal=normal, point=point, POC=POC, slopeForm=False)
    else:
        return render_template("circle/circle_normal.html", normal=None)


@app.route('/circle/perpendicularDistance', methods=['GET', 'POST'])
def perpendicular_distance():
    if request.method == 'POST':
        x_val = float(request.form['x_val'])
        y_val = float(request.form['y_val'])
        point = Point(x_val, y_val)
        g = float(request.form.get('gCoefficient'))
        f = float(request.form.get('fCoefficient'))
        c = float(request.form.get('cConstant'))
        circle = Circle(g=g, f=f, c=c)
        distance = circle.perpendicular_distance(point)
        Circle.plot(circle, point)
        return render_template('circle/perpendicular_dist.html', point=point, circle=circle, distance=distance)
    return render_template('circle/perpendicular_dist.html', distance=None)


@app.route('/circle/footOfPerpendicular', methods=['GET', 'POST'])
def footOfPerpendicular():
    if request.method == 'POST':
        x_val = float(request.form['x_val'])
        y_val = float(request.form['y_val'])
        point = Point(x_val, y_val)
        g = float(request.form.get('gCoefficient'))
        f = float(request.form.get('fCoefficient'))
        c = float(request.form.get('cConstant'))
        circle = Circle(g=g, f=f, c=c)
        foot = circle.foot_of_perpendicular(point)
        Circle.plot(circle, point, foot)
        return render_template('circle/foot_of_per.html', point=point, circle=circle, foot=foot)
    else:
        return render_template('circle/foot_of_per.html', foot=None)


@app.route('/circle/positionOfPoint', methods=['GET', 'POST'])
def position_of_point():
    if request.method == 'POST':
        x_val = float(request.form['x_val'])
        y_val = float(request.form['y_val'])
        point = Point(x_val, y_val)
        g = float(request.form.get('gCoefficient'))
        f = float(request.form.get('fCoefficient'))
        c = float(request.form.get('cConstant'))
        circle = Circle(g=g, f=f, c=c)
        position = circle.pos_of_point(point)
        d = {
            0: "on",
            1: "outside of",
            -1: "inside of"
        }
        Circle.plot(circle, point)
        return render_template('circle/positionOfpoint.html', point=point, circle=circle, pos=d[position])
    else:
        return render_template('circle/positionOfpoint.html', pos=None)


@app.route('/circle/positionOfLine', methods=['GET', 'POST'])
def position_of_line():
    if request.method == 'POST':
        A = float(request.form.get('aCoefficient'))
        B = float(request.form.get('bCoefficient'))
        C = float(request.form.get('cConstant'))
        line = Line(a = A, b = B, c = C)
        g = float(request.form.get('gCoefficient'))
        f = float(request.form.get('fCoefficient'))
        c = float(request.form.get('cConstant'))
        circle = Circle(g=g, f=f, c=c)
        position = circle.pos_of_line(line)
        d = {
            0: "on",
            1: "outside of",
            -1: "inside of"
        }
        Circle.plot(circle, line)
        return render_template('circle/positionOfLine.html', line=line, circle=circle, pos=d[position])
    else:
        return render_template('circle/positionOfLine.html', pos=None)


@app.route('/circle/separation', methods=['GET', 'POST'])
def separation():
    if request.method == 'POST':
        g1 = float(request.form.get('gCoefficient1'))
        f1 = float(request.form.get('fCoefficient1'))
        c1 = float(request.form.get('cConstant1'))
        circle1 = Circle(g=g1, f=f1, c=c1)

        g2 = float(request.form.get('gCoefficient2'))
        f2 = float(request.form.get('fCoefficient2'))
        c2 = float(request.form.get('cConstant2'))
        circle2 = Circle(g=g2, f=f2, c=c2)
        distance = Circle.distance(circle1, circle2)
        Circle.plot(circle1, circle2)
        return render_template("circle/separation_of_circles.html", circle1=circle1, circle2=circle2, separation=distance)
    else:
        return render_template('circle/separation_of_circles.html', separation=None)


@app.route('/circle/relative_pos', methods=['GET', 'POST'])
def relative_pos():
    if request.method == 'POST':
        g1 = float(request.form.get('gCoefficient1'))
        f1 = float(request.form.get('fCoefficient1'))
        c1 = float(request.form.get('cConstant1'))
        circle1 = Circle(g=g1, f=f1, c=c1)

        g2 = float(request.form.get('gCoefficient2'))
        f2 = float(request.form.get('fCoefficient2'))
        c2 = float(request.form.get('cConstant2'))
        circle2 = Circle(g=g2, f=f2, c=c2)
        d = {
            1: 'outside',
            0: 'on',
            -1: 'inside'
        }
        pos = Circle.relative_pos(circle1, circle2)
        Circle.plot(circle1, circle2)
        return render_template("circle/relative_pos.html", circle1=circle1, circle2=circle2, pos=d[pos])
    # else:
    return render_template('circle/relative_pos.html', pos=None)


@app.route('/graphs')
def graphs():
    return render_template("Graph.html")


if __name__ == '__main__':
    app.run(debug=True)
