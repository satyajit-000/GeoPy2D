function toggleSolveButton() {
    var equation1Checkbox = document.getElementById('equation1Checkbox');
    var equation2Checkbox = document.getElementById('equation2Checkbox');
    var solveButton = document.getElementById('solveButton');
    var equation1 = document.getElementById('equation1');
    var equation2 = document.getElementById('equation2');
    var btn1 = document.getElementById('button1')
    var btn2 = document.getElementById('button2')


    if (equation1Checkbox.checked) {
        equation1.style.display = 'block';
        btn1.classList.replace("btn-outline-warning", "btn-warning")
    } else {
        equation1.style.display = 'none';
        btn1.classList.replace("btn-warning", "btn-outline-warning")
    }

    if (equation2Checkbox.checked) {
        equation2.style.display = 'block';
        btn2.classList.replace("btn-outline-warning", "btn-warning")
    } else {
        equation2.style.display = 'none';
        btn2.classList.replace("btn-warning", "btn-outline-warning")
    }

    if (equation1Checkbox.checked && equation2Checkbox.checked) {
        solveButton.style.display = 'block';
    } else {
        solveButton.style.display = 'none';
    }
}
