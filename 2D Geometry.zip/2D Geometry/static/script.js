
document.getElementById('equationType').addEventListener('change', function () {
    var standardFormFields = document.getElementById('standardFormFields');
    var slopeInterceptFormFields = document.getElementById('slopeInterceptFormFields');
    var pointSlopeFormFields = document.getElementById('pointSlopeFormFields');
    var twoPointFormFields = document.getElementById('twoPointFormFields');

    if (this.value === 'standard') {
        standardFormFields.style.display = 'block';
        slopeInterceptFormFields.style.display = 'none';
        pointSlopeFormFields.style.display = 'none';
        twoPointFormFields.style.display = 'none';
    } else if (this.value === 'slopeIntercept') {
        standardFormFields.style.display = 'none';
        slopeInterceptFormFields.style.display = 'block';
        pointSlopeFormFields.style.display = 'none';
        twoPointFormFields.style.display = 'none';
    } else if (this.value === 'pointSlope') {
        standardFormFields.style.display = 'none';
        slopeInterceptFormFields.style.display = 'none';
        pointSlopeFormFields.style.display = 'block';
        twoPointFormFields.style.display = 'none';
    } else if (this.value === 'twoPoint') {
        standardFormFields.style.display = 'none';
        slopeInterceptFormFields.style.display = 'none';
        pointSlopeFormFields.style.display = 'none';
        twoPointFormFields.style.display = 'block';
    } else {
        standardFormFields.style.display = 'none';
        slopeInterceptFormFields.style.display = 'none';
        pointSlopeFormFields.style.display = 'none';
        twoPointFormFields.style.display = 'none';
    }
    button.style.display = 'block'
});
