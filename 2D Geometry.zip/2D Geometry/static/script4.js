
document.getElementById('equationType').addEventListener('change', function () {
    var standardFormFields = document.getElementById('standardFormFields');
    var centreRadiusFormFields = document.getElementById('centreRadiusFormFields');
    var generalFormFields = document.getElementById('generalFormFields');
    var twoPointFormFields = document.getElementById('twoPointFormFields');

    if (this.value === 'standard') {
        standardFormFields.style.display = 'block';
        centreRadiusFormFields.style.display = 'none';
        generalFormFields.style.display = 'none';
        twoPointFormFields.style.display = 'none';
    } else if (this.value === 'centreRadius') {
        standardFormFields.style.display = 'none';
        centreRadiusFormFields.style.display = 'block';
        generalFormFields.style.display = 'none';
        twoPointFormFields.style.display = 'none';
    } else if (this.value === 'general') {
        standardFormFields.style.display = 'none';
        centreRadiusFormFields.style.display = 'none';
        generalFormFields.style.display = 'block';
        twoPointFormFields.style.display = 'none';
    } else if (this.value === 'twoPoint') {
        standardFormFields.style.display = 'none';
        centreRadiusFormFields.style.display = 'none';
        generalFormFields.style.display = 'none';
        twoPointFormFields.style.display = 'block';
    } else {
        standardFormFields.style.display = 'none';
        centreRadiusFormFields.style.display = 'none';
        generalFormFields.style.display = 'none';
        twoPointFormFields.style.display = 'none';
    }
    button.style.display = 'block'
});
